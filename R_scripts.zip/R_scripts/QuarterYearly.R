# Load libraries
library(readr) # To import csv
library(tidyverse) # To easily manipulate
library(openair) # To plot the air pollution stuff
library(dplyr)

# Import files
data <- readLines(file("stdin"), warn = FALSE)

DF_George <- read.csv(text = data, header = TRUE, sep = ',')

# Convert date to datetime class

DF_George <- DF_George %>%
  mutate(date = as.POSIXct(date,
                           format="%m/%d/%Y %H:%M",
                           tz= "EST"))

# Make sure that your dataframe has "date" "pm25" "pm10" variables. They must be lowercase and written like this
# Note the capital letters in the function names):


# Open PNG file system
png("plot_pm_QuartYearly.png", width = 2800, height = 2400, res = 300)

# Print the Daily plot to the PNG file
# make DF with data from previous day
  
#WE CAN CHANGE SCALE TO QUARTER HOURLY / 30 MIN
timePlot(DF_George, pollutant = c("pm25","pm10"), scale = "6 hourly",
         main = "Yearly-Quarter PM10 and PM25  Levels at Emory University (MSC)")

# Close the PNG file system
dev.off()